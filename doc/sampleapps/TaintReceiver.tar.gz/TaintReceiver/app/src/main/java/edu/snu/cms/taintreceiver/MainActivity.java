package edu.snu.cms.taintreceiver;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import dalvik.system.Taint;


public class MainActivity extends Activity {
    private final String TAG = "TaintReceiver";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        Log.i(TAG, "receiving intent");

        receiveChar(intent);
        receiveByte(intent);
        receiveString(intent);

        receiveByteArray(intent);
        receiveBooleanArray(intent);
        receiveCharArray(intent);
        receiveLongArray(intent);
        receiveIntArray(intent);
        receiveFloatArray(intent);
        receiveDoubleArray(intent);
        receiveStringArray(intent);
    }

    private void receiveString(Intent intent) {
        String b;
        b = intent.getStringExtra("string");

        handleCaseResult("ipc-string", Taint.getTaintString(b), Taint.TAINT_ACCELEROMETER);
    }

    private void receiveChar(Intent intent) {
        char b;
        b = intent.getCharExtra("char", (char)'a');

        handleCaseResult("ipc-char", Taint.getTaintChar(b), Taint.TAINT_CAMERA);
    }

    private void receiveByte(Intent intent) {
        byte b;
        b = intent.getByteExtra("byte", (byte)'a');

        handleCaseResult("ipc-byte", Taint.getTaintByte(b), Taint.TAINT_CAMERA);
    }

    private void receiveStringArray(Intent intent) {
        String[] stringArray = intent.getStringArrayExtra("stringArray");

        handleCaseResult("ipc-stringArray", Taint.getTaintObjectArray(stringArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-stringArray[0]", Taint.getTaintString(stringArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-stringArray[1]", Taint.getTaintString(stringArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveDoubleArray(Intent intent) {
        double[] doubleArray = intent.getDoubleArrayExtra("doubleArray");

        handleCaseResult("ipc-doubleArray", Taint.getTaintDoubleArray(doubleArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-doubleArray[0]", Taint.getTaintDouble(doubleArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-doubleArray[1]", Taint.getTaintDouble(doubleArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveFloatArray(Intent intent) {
        float[] floatArray = intent.getFloatArrayExtra("floatArray");

        handleCaseResult("ipc-floatArray", Taint.getTaintFloatArray(floatArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-floatArray[0]", Taint.getTaintFloat(floatArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-floatArray[1]", Taint.getTaintFloat(floatArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveIntArray(Intent intent) {
        int[] intArray = intent.getIntArrayExtra("intArray");

        handleCaseResult("ipc-intArray", Taint.getTaintIntArray(intArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-intArray[0]", Taint.getTaintInt(intArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-intArray[1]", Taint.getTaintInt(intArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveLongArray(Intent intent) {
        long[] longArray = intent.getLongArrayExtra("longArray");

        handleCaseResult("ipc-longArray", Taint.getTaintLongArray(longArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-longArray[0]", Taint.getTaintLong(longArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-longArray[1]", Taint.getTaintLong(longArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveCharArray(Intent intent) {
        char[] charArray = intent.getCharArrayExtra("charArray");

        Log.i(TAG, "charArray[0]:" + charArray[0]);
        Log.i(TAG, "charArray[1]:" + charArray[1]);

        handleCaseResult("ipc-charArray", Taint.getTaintCharArray(charArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-charArray[0]", Taint.getTaintChar(charArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-charArray[1]", Taint.getTaintChar(charArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveBooleanArray(Intent intent) {
        boolean[] booleanArray = intent.getBooleanArrayExtra("booleanArray");

        handleCaseResult("ipc-booleanArray", Taint.getTaintBooleanArray(booleanArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-booleanArray[0]", Taint.getTaintBoolean(booleanArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-booleanArray[1]", Taint.getTaintBoolean(booleanArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void receiveByteArray(Intent intent) {
        byte[] byteArray = intent.getByteArrayExtra("byteArray");

        handleCaseResult("ipc-byteArray", Taint.getTaintByteArray(byteArray),
                Taint.TAINT_ACCELEROMETER | Taint.TAINT_ACCOUNT);
        handleCaseResult("ipc-byteArray[0]", Taint.getTaintByte(byteArray[0]), Taint.TAINT_ACCELEROMETER);
        handleCaseResult("ipc-byteArray[1]", Taint.getTaintByte(byteArray[1]), Taint.TAINT_ACCOUNT);
    }

    private void handleCaseResult(String testCase, int result, int answer) {
        if(result == answer) {
            Log.i(TAG, "[SUCCESS - " + testCase + "]" + "\tresult: " + result + ",\tanswer:" + answer);
        } else {
            Log.i(TAG, "[FAIL - " + testCase + "]" + "\tresult: " + result + ",\tanswer:" + answer);
        }
    }
}
